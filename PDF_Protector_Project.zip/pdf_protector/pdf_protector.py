import sys
import PyPDF2

def password_protected_pdf(input_file,output_file,password):
    try:
        with open (input_file,'rb')as f:
            pdf_reader=PyPDF2.PdfReader(f)
            pdf_wirter=PyPDF2.PdfWriter()
            for page in range(len(pdf_reader.pages)):
                pdf_wirter.add_page(pdf_reader.pages[page])

            pdf_wirter.encrypt(password)
            
            with open (output_file,'wb')as p:
                pdf_wirter.write(p)
        print(f"File {input_file} Now Password Protected And Save as {output_file} ")

    except FileNotFoundError:
        print(f"The File {input_file} Was Not Found")
    except PyPDF2.utils.PdfReadError:
        print(f"The File {input_file} is Not Valid PDF")
    except Exception as e:
        print("Error :{e}")

def main():
    if len(sys.argv) !=4:
        print("Please Mention <Input_File> <Output_File> and <Password> in Command Line(With Script Name )")
        sys.exit(1)
    input_file=sys.argv[1]
    output_file=sys.argv[2]
    password=sys.argv[3]
    password_protected_pdf(input_file,output_file,password)
    
if __name__=='__main__':
    main()
