import socket
import concurrent.futures
import sys

RED="\033[91m"
GREEN="\033[92m"
RESET="\033[0m"
def get_banner(sock):
    try:
        sock.settimeout(1)
        banner=sock.recv(1024).decode().strip()
        return banner
    except:
        return ""

def final_result(result):
    formatted_result="Port Scan Result:\n"
    formatted_result +="{:<8} {:<15} {:<10}\n".format("Port","Service","Status") 
    formatted_result += '-' * 85 +"\n"
    for port,service,banner,status in result:
        if status:
            formatted_result += f"{RED}{port:<8} {service:<15} {'Open':<10}{RESET}\n"
            if banner:
                banner_lines=banner.split('\n')
                for line in banner_lines:
                    formatted_result += f"{GREEN}{'':<8}{line}{RESET}\n"
    return formatted_result



def port_scan(ip,port):
    try:
        sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
        sock.settimeout(1)
        result=sock.connect_ex((ip,port))
        if result==0:
            try:
                service=socket.getservbyport(port,'tcp')
            except:
                service='Unknown'
            banner=get_banner(sock)
            return port,service,banner,True
        else:
            return port,"","",False
    except:
        return port,"","",False
    finally:
        sock.close()
def port_range(tg_ip,start_port,end_port):
    tg_ip=socket.gethostbyname(tg_ip)
    print(f"Starting port scan on host:{tg_ip}")

    results=[]
    with concurrent.futures.ThreadPoolExecutor(max_workers=300)as ex:
        futures={ex.submit(port_scan,tg_ip,port):port for port in range(start_port,end_port+1)}
        total_ports=end_port-start_port+1
        for i,future in enumerate(concurrent.futures.as_completed(futures),start=1):
            port,service,banner,status=future.result()
            results.append((port,service,banner,status))
            sys.stdout.write(f"\rProgress: {i}/{total_ports} ports scanned")
            sys.stdout.flush()
    sys.stdout.write("\n")
    print(final_result(results))

if __name__=='__main__':
    tg_ip=input("Enter Your Target IP: ")
    start_port=int(input("Enter The Start Port : "))
    end_port=int(input("Enter The End Port : "))
    port_range(tg_ip,start_port,end_port)